# gimese_Grupo_CSIC_883033

Grupo  Formado por investigadores del IESTA (Instituto de Estadistica de la Facultad de Ciencias Económicas y de Administración), FCEA, Udelar